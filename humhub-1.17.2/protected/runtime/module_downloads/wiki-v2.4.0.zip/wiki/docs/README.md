# Wiki

Create and edit pages with this powerful tool. Compile a collaborative knowledge base, display information and share it with your network.

## Overview

- Create individual Wikis for every Space and Profile
- Edit them with ease using our WYSIWYG editor
- Link between pages and even individual paragraphs
- Keep track on changes with a build in page history 
- Include pictures and format them on-the-fly
- Move content between Spaces
