<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\wiki\controllers;

use humhub\modules\admin\components\Controller;
use humhub\modules\wiki\models\ConfigForm;
use Yii;

class ConfigController extends Controller
{
    public function actionIndex()
    {
        $form = new ConfigForm();

        if ($form->load(Yii::$app->request->post()) && $form->save()) {
            $this->view->saved();
        }

        return $this->render('index', ['model' => $form]);
    }
}
