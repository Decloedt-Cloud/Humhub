<?php

return [
    'modules' => ['calendar'],
    'fixtures' => [
        'default',
        'calendar_entry' => 'humhub\modules\calendar\tests\codeception\fixtures\CalendarEntryFixture',
    ],
];
