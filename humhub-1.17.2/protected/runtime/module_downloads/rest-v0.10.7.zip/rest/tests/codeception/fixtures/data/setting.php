<?php

return [
    ['name' => 'enableJwtAuth', 'value' => '1', 'module_id' => 'rest'],
    ['name' => 'enableBearerAuth', 'value' => '1', 'module_id' => 'rest'],
    ['name' => 'enableQueryParamAuth', 'value' => '1', 'module_id' => 'rest'],
    ['name' => 'enableBasicAuth', 'value' => '1', 'module_id' => 'rest'],
];
