<?php

return [
    ['message' => 'Comment 1 of the Post 1', 'object_model' => 'humhub\modules\post\models\Post', 'object_id' => 1, 'created_at' => '2021-05-13 09:33:00', 'created_by' => 1, 'updated_at' => '2021-05-13 09:33:00', 'updated_by' => 1],
];
