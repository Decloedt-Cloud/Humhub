<?php

return [
    ['guid' => 'e0acdc54-13c8-4778-adc1-7302e324e100', 'object_model' => 'humhub\modules\activity\models\Activity', 'object_id' => 100, 'visibility' => '0', 'pinned' => '0', 'archived' => '0', 'contentcontainer_id' => 4, 'created_at' => '2021-05-14 14:40:00', 'created_by' => '2', 'updated_at' => '2021-05-14 14:40:00', 'updated_by' => '2', 'stream_channel' => 'activity'],
    ['guid' => 'e0acdc54-13c8-4778-adc1-7302e324e101', 'object_model' => 'humhub\modules\activity\models\Activity', 'object_id' => 101, 'visibility' => '0', 'pinned' => '0', 'archived' => '0', 'contentcontainer_id' => 4, 'created_at' => '2021-05-14 14:40:00', 'created_by' => '3', 'updated_at' => '2021-05-14 14:40:00', 'updated_by' => '3', 'stream_channel' => 'activity'],
    ['guid' => 'e0acdc54-13c8-4778-adc1-7302e324e102', 'object_model' => 'humhub\modules\activity\models\Activity', 'object_id' => 102, 'visibility' => '0', 'pinned' => '0', 'archived' => '0', 'contentcontainer_id' => 4, 'created_at' => '2021-05-14 14:40:00', 'created_by' => '3', 'updated_at' => '2021-05-14 14:40:00', 'updated_by' => '3', 'stream_channel' => 'activity'],
    ['guid' => 'e0acdc54-13c8-4778-adc1-7302e324e103', 'object_model' => 'humhub\modules\activity\models\Activity', 'object_id' => 103, 'visibility' => '0', 'pinned' => '0', 'archived' => '0', 'contentcontainer_id' => 7, 'created_at' => '2021-05-14 14:40:00', 'created_by' => '4', 'updated_at' => '2021-05-14 14:40:00', 'updated_by' => '4', 'stream_channel' => 'activity'],
];
