<?php

if (!Yii::$app->urlManager->enablePrettyUrl) {
    return 'Please enable URL Rewriting: https://docs.humhub.org/docs/admin/installation/#pretty-urls';
}

return null;
