<?php

return [
    ['name' => 'First test topic from container 1', 'module_id' => 'topic', 'contentcontainer_id' => '1', 'type' => 'humhub\modules\topic\models\Topic', 'color' => '#F09', 'sort_order' => 100],
    ['name' => 'Topic name from container 2', 'module_id' => 'topic', 'contentcontainer_id' => '2', 'type' => 'humhub\modules\topic\models\Topic', 'color' => '#039', 'sort_order' => 200],
    ['name' => 'Third test topic', 'module_id' => 'topic', 'contentcontainer_id' => '3', 'type' => 'humhub\modules\topic\models\Topic', 'color' => '#EE0', 'sort_order' => 300],
    ['name' => 'Second test topic from container 2', 'module_id' => 'topic', 'contentcontainer_id' => '2', 'type' => 'humhub\modules\topic\models\Topic', 'color' => '#039', 'sort_order' => 400],
    ['name' => 'Test topic from container 4', 'module_id' => 'topic', 'contentcontainer_id' => '4', 'type' => 'humhub\modules\topic\models\Topic', 'color' => '#039', 'sort_order' => 500],
];
