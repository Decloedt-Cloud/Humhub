<?php

return [
    ['guid' => 'aa2b3171-b14e-4a7f-a707-9ee2e2921e16', 'object_model' => 'humhub\modules\post\models\Post', 'object_id' => '1', 'file_name' => 'file_name1.txt', 'mime_type' => 'text/plain', 'size' => '1024', 'created_at' => '2021-05-14 20:27:42', 'created_by' => '1', 'updated_at' => '2021-05-14 20:27:42', 'updated_by' => '1', 'show_in_stream' => '0', 'hash_sha1' => '328b5663cc8752d0989e8cc03829ead535431b64'],
];
