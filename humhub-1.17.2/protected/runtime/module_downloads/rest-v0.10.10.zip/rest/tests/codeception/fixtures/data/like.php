<?php

return [
    ['object_model' => 'humhub\modules\post\models\Post', 'object_id' => 1, 'created_at' => '2021-05-13 09:33:00', 'created_by' => 3, 'updated_at' => '2021-05-13 09:33:00', 'updated_by' => 3],
    ['object_model' => 'humhub\modules\post\models\Post', 'object_id' => 2, 'created_at' => '2021-05-13 09:34:00', 'created_by' => 2, 'updated_at' => '2021-05-13 09:34:00', 'updated_by' => 2],
    ['object_model' => 'humhub\modules\post\models\Post', 'object_id' => 1, 'created_at' => '2021-05-13 09:36:00', 'created_by' => 4, 'updated_at' => '2021-05-13 09:36:00', 'updated_by' => 4],
];
