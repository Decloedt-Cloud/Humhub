<?php

namespace humhub\modules\mail\widgets;

/**
 * Class Notifications
 * @package humhub\modules\mail\widgets
 * @deprecated since 2.0 see https://github.com/humhub/humhub/issues/4364
 */
class Notifications extends NotificationInbox
{
}
